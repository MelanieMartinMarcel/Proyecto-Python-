# Proyecto-Final-Phyton
Creacion del proyecto

Hasta el momento se tuvieron en cuenta los siguientes puntos del TPO:

1) Poseer al menos 4 páginas html (Falta agregar más información)

2) Se utilizaron etiquetas semánticas para estructurar el sitio.

3) Se incluyo formulario de contacto, falta contemplar validaciones mediante Javascript.

4) Se utilizaron íconos de FontAwesome y Google Fonts.

5) Se incluyeron 3 puntos de corte para tamaños de dispositivos distintos.

6) Se estructuro HTML maquetado con Flexbox y/o Grid.

7) Se incluyo Bootstrap en el formulario
